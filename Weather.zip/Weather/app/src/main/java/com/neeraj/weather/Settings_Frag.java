package com.neeraj.weather;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import static android.content.Context.MODE_PRIVATE;

public class Settings_Frag extends Fragment {

    TextView username;
    Spinner units;
    Button submit;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_settings_, container, false);
        username=view.findViewById(R.id.tv_settings_username);
        units=view.findViewById(R.id.spinner_settings_metric_units);
        submit=view.findViewById(R.id.bt_settings_submit);

        SharedPreferences preferences = getActivity().getSharedPreferences("Login", Context.MODE_PRIVATE);
        username.setText("Hello "+preferences.getString("username",null));
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String unit_val=units.getSelectedItem().toString();
                if (unit_val.equals("Select Unit")){

                }else if (unit_val.equals("Fahrenheit"))
                {
                    SharedPreferences.Editor editor= getContext().getSharedPreferences("Login",MODE_PRIVATE).edit();
                    editor.putString("unit",unit_val);
                    editor.apply();

                }else if (unit_val.equals("Celsius")){
                    SharedPreferences.Editor editor= getContext().getSharedPreferences("Login",MODE_PRIVATE).edit();
                    editor.putString("unit",unit_val);
                    editor.apply();

                }
                Toast.makeText(getContext(), "Settings Saved", Toast.LENGTH_SHORT).show();
            }
        });
        return view;
    }
}