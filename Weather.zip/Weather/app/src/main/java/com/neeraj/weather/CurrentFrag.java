package com.neeraj.weather;

import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.LocationSettingsStatusCodes;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import static android.content.Context.MODE_PRIVATE;

public class CurrentFrag extends Fragment {

    private static final long UPDATE_IN_MILLI = 10000;
    private static final long FAST_UPDATE_IN_MILLI = 5000;
    private static final long REQUEST_CHECK_SETTINGS = 100;

    private FusedLocationProviderClient fusedLocationProviderClient;
    private SettingsClient settingsClient;
    private LocationRequest locationRequest;
    private LocationSettingsRequest locationSettingsRequest;
    private LocationCallback locationCallback;
    private Location location;
    private boolean locationUpdate;
    ProgressDialog progressDialog;
    String unit;
TextView username,city_name,temp_max,temp_min;
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_current, container, false);
        username=(TextView) root.findViewById(R.id.tv_username);

        temp_max=(TextView)root.findViewById(R.id.tv_temp_max);
        temp_min=(TextView)root.findViewById(R.id.tv_temp_min);
        city_name=(TextView)root.findViewById(R.id.tv_city_name);
        init();
        checkPermissions();
        SharedPreferences preferences = getActivity().getSharedPreferences("Login", MODE_PRIVATE);
        username.setText("Hello "+preferences.getString("username",null));
        unit=preferences.getString("unit",null);
        Toast.makeText(getContext(), "chala", Toast.LENGTH_SHORT).show();
        return root;
    }

    private void checkPermissions() {
        Dexter.withContext(getContext()).withPermission(Manifest.permission.ACCESS_FINE_LOCATION).withListener(new PermissionListener() {
            @Override
            public void onPermissionGranted(PermissionGrantedResponse permissionGrantedResponse) {
                locationUpdate = true;
                Log.e("permission_result", "Granted");
                setLocation();
            }

            @Override
            public void onPermissionDenied(PermissionDeniedResponse permissionDeniedResponse) {
                Log.e("permission_result", "Granted");
                openSettings();

            }

            @Override
            public void onPermissionRationaleShouldBeShown(PermissionRequest permissionRequest, PermissionToken permissionToken) {

                permissionToken.continuePermissionRequest();
            }
        }).check();
    }

    private void setLocation() {
        settingsClient.checkLocationSettings(locationSettingsRequest).addOnSuccessListener(new OnSuccessListener<LocationSettingsResponse>() {
            @Override
            public void onSuccess(LocationSettingsResponse locationSettingsResponse) {
                if (ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                        && ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
                {

                                     return;
                }
                fusedLocationProviderClient.requestLocationUpdates(locationRequest, locationCallback, Looper.myLooper());

                if (location!=null)
                {
                    String lattitude = String.valueOf(location.getLatitude());
                    String longitude = String.valueOf(location.getLongitude());

                    showWeatherReport(lattitude,longitude);

                }else
                {
                    checkPermissions();
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                int code = ((ApiException)e).getStatusCode();

                switch (code)
                {
                    case LocationSettingsStatusCodes.RESOLUTION_REQUIRED:
                        ResolvableApiException re = (ResolvableApiException) e;
                            try
                            {
                                re.startResolutionForResult(getActivity(), (int) REQUEST_CHECK_SETTINGS);
                            }
                            catch (IntentSender.SendIntentException ex)
                            {
                                ex.printStackTrace();
                            }
                            break;
                    case LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE:
                        Toast.makeText(getContext(), "Please Check Your Settings ", Toast.LENGTH_SHORT).show();
                            break;
                }

            }
        });
    }



    private void showWeatherReport(final String lattitude, final String longitude)
    {
        progressDialog= new ProgressDialog(getContext());
        progressDialog.setMessage("Please Wait..");
        progressDialog.setTitle("Loading.");
        progressDialog.setCancelable(false);
        progressDialog.show();
        RequestQueue rq= Volley.newRequestQueue(getContext());
        String url ="https://api.openweathermap.org/data/2.5/weather?lat="+lattitude+"&lon="+longitude+"&appid=638bd8e03959a48787aff704f2db772f";

        Log.e("finalURLLogin--->", url );
        StringRequest sr=new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response)
            {
                progressDialog.dismiss();
             try {


                 SharedPreferences.Editor editor= getContext().getSharedPreferences("Login",MODE_PRIVATE).edit();
                 editor.putString("lattitude",lattitude);
                 editor.putString("longitude",longitude);
                 editor.apply();
                 JSONObject jo = new JSONObject(response);
                 JSONObject data=new JSONObject(String.valueOf(jo.getJSONObject("main")));
                 double maxTemp=Double.valueOf(data.getString("temp_max"));
                 double minTemp=Double.valueOf(data.getString("temp_min"));

               if (unit.equals("Fahrenheit")) {
                   maxTemp = (maxTemp - 273.15) * 9/5 + 32 ;
                   minTemp = (minTemp - 273.15) * 9/5 + 32;
               }
               else {
                   maxTemp = maxTemp - 273.15;
                   minTemp = minTemp - 273.15;
               }
                 temp_max.setText(String.valueOf(maxTemp));
                 temp_min.setText(String.valueOf(minTemp));

                 city_name.setText(jo.getString("name"));

             }
             catch (JSONException e)
             {

             }

;
                Log.e("response:-->", response );
            }
        }, new Response.ErrorListener()
        {
            @Override
            public void onErrorResponse(VolleyError error)
            {
                progressDialog.dismiss();
                Toast.makeText(getContext(), "Some Technical Error!! Try Again", Toast.LENGTH_SHORT).show();
                // Toast.makeText(third.this, "DATA NOT REGISTER", Toast.LENGTH_SHORT).show();
                Log.e("error", error.getMessage() );
            }
        });

        rq.add(sr);

    }

    private void openSettings()
    {
        Intent intent = new Intent();
        intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package",BuildConfig.APPLICATION_ID,null);
        intent.setData(uri);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        getContext().startActivity(intent);
    }

    private void init()
    {
        fusedLocationProviderClient= LocationServices.getFusedLocationProviderClient(getContext());

        settingsClient=LocationServices.getSettingsClient(getContext());

        locationCallback= new LocationCallback(){
            @Override
            public void onLocationResult(LocationResult locationResult) {
                super.onLocationResult(locationResult);

                location=locationResult.getLastLocation();
            }
        };

        locationUpdate=false;
        locationRequest= new LocationRequest();
        locationRequest.setInterval(UPDATE_IN_MILLI);
        locationRequest.setFastestInterval(FAST_UPDATE_IN_MILLI);
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder();
        builder.addLocationRequest(locationRequest);
        locationSettingsRequest=builder.build();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        switch (resultCode){
            case AppCompatActivity.RESULT_OK:
                Log.e("permission_result", "Granted" );
                break;
            case Activity.RESULT_CANCELED:
                Log.e("permission_result", "Denied" );
                locationUpdate=false;
                break;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
}