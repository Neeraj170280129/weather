package com.neeraj.weather;

import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import static android.content.Context.MODE_PRIVATE;

public class Date_Frag extends Fragment {


    TextView city_name,mintemp,maxtemp;
    Spinner cities;
    ProgressDialog progressDialog;
    String unit;
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {

        View root = inflater.inflate(R.layout.fragment_date, container, false);
        SharedPreferences preferences = getActivity().getSharedPreferences("Login", MODE_PRIVATE);
        unit=preferences.getString("unit",null);
        city_name=(TextView) root.findViewById(R.id.tv_dateFrag_city_name);
        maxtemp=(TextView) root.findViewById(R.id.tv_dateFrag_temp_max);
        mintemp=(TextView) root.findViewById(R.id.tv_dateFrag_temp_min);
        cities=(Spinner) root.findViewById(R.id.spinner_cities);

        cities.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String state=cities.getSelectedItem().toString();
                if (state.equals("Select City")){
                    Log.e("state", "Do Nothing" );
                }
                else if (state.equals("Delhi"))
                {
                    String lattitude="28.7041",longitude="77.1025";
                    showWeatherReport(lattitude,longitude );
                }else if(state.equals("Mumbai"))
                {

                    String lattitude="19.0760",longitude="72.8777";
                    showWeatherReport(lattitude,longitude );
                }
                else {
                    String lattitude="28.5355",longitude="77.3910";
                    showWeatherReport(lattitude,longitude );
                }
            }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
});

        return root;
    }
    private void showWeatherReport(String lattitude, String longitude)
    {
        progressDialog= new ProgressDialog(getContext());
        progressDialog.setMessage("Please Wait..");
        progressDialog.setTitle("Loading.");
        progressDialog.setCancelable(false);
        progressDialog.show();
        RequestQueue rq= Volley.newRequestQueue(getContext());
        String url ="https://api.openweathermap.org/data/2.5/weather?lat="+lattitude+"&lon="+longitude+"&appid=638bd8e03959a48787aff704f2db772f";

        Log.e("finalURLLogin--->", url );
        StringRequest sr=new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response)
            {
                progressDialog.dismiss();
                try {
                    JSONObject jo = new JSONObject(response);
                    JSONObject data=new JSONObject(String.valueOf(jo.getJSONObject("main")));
                    double maxTemp=Double.valueOf(data.getString("temp_max"));
                    double minTemp=Double.valueOf(data.getString("temp_min"));

                    if (unit.equals("Fahrenheit")) {
                        maxTemp = (maxTemp - 273.15) * 9/5 + 32 ;
                        minTemp = (minTemp - 273.15) * 9/5 + 32;
                    }
                    else {
                        maxTemp = maxTemp - 273.15;
                        minTemp = minTemp - 273.15;
                    }
                    maxtemp.setText(String.valueOf(maxTemp));
                    mintemp.setText(String.valueOf(minTemp));

                    city_name.setText(jo.getString("name"));

                }
                catch (JSONException e)
                {

                }

                ;
                Log.e("response:-->", response );
            }
        }, new Response.ErrorListener()
        {
            @Override
            public void onErrorResponse(VolleyError error)
            {
                progressDialog.dismiss();
                Toast.makeText(getContext(), "Some Technical Error!! Try Again", Toast.LENGTH_SHORT).show();
                // Toast.makeText(third.this, "DATA NOT REGISTER", Toast.LENGTH_SHORT).show();
                Log.e("error", error.getMessage() );
            }
        });

        rq.add(sr);

    }
}