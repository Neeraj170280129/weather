package com.neeraj.weather;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class Adapter_for_weatherReport extends ArrayAdapter<model_class_for_weatherReport>
{
    List<model_class_for_weatherReport> dataList;
    Context context;
    int resource;

    public Adapter_for_weatherReport(@NonNull Context context, int resource, List<model_class_for_weatherReport> dataList) {
        super(context, resource, dataList);
        this.dataList = dataList;
        this.context = context;
        this.resource = resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater layoutInflater = LayoutInflater.from(context);
        View view = layoutInflater.inflate(resource,null);
        TextView date,name,maxTemp,minTemp,windSpeed;

        date=(TextView)view.findViewById(R.id.tv_listView_date);
        name=(TextView)view.findViewById(R.id.tv_listView_city_name);
        maxTemp=(TextView)view.findViewById(R.id.tv_listView_max_temp);
        minTemp=(TextView)view.findViewById(R.id.tv_listView_min_temp);
        windSpeed=(TextView)view.findViewById(R.id.tv_listView_windSpeed);

        model_class_for_weatherReport weatherReport =dataList.get(position);

        date.setText(weatherReport.getDate());
        name.setText(weatherReport.getPlace());
        maxTemp.setText(weatherReport.getMaxTemp());
        minTemp.setText(weatherReport.getMinTemp());
        windSpeed.setText(weatherReport.getWindSpeed());

        return view;
    }
}
