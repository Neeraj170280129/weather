package com.neeraj.weather;

public class model_class_for_weatherReport
{
    String date,place,maxTemp,minTemp,windSpeed;

    public model_class_for_weatherReport(String date, String place, String maxTemp, String minTemp, String windSpeed) {
        this.date = date;
        this.place = place;
        this.maxTemp = maxTemp;
        this.minTemp = minTemp;
        this.windSpeed = windSpeed;
    }

    public String getDate() {
        return date;
    }

    public String getPlace() {
        return place;
    }

    public String getMaxTemp() {
        return maxTemp;
    }

    public String getMinTemp() {
        return minTemp;
    }

    public String getWindSpeed() {
        return windSpeed;
    }
}
