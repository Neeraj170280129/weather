package com.neeraj.weather;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;


public class Days_Report_Frag extends Fragment {

    TextView username;
    ListView listView;
    List<model_class_for_weatherReport> dataList;
    ProgressDialog progressDialog;
    String lattitude,longitude;
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        View root = inflater.inflate(R.layout.fragment_days_report, container, false);
        username=(TextView)root.findViewById(R.id.tv_days_report_username);
        listView=(ListView)root.findViewById(R.id.listView_days_report);

        dataList= new ArrayList<>();

        SharedPreferences preferences = getActivity().getSharedPreferences("Login", Context.MODE_PRIVATE);
        username.setText("Hello "+preferences.getString("username",null));
        lattitude=preferences.getString("lattitude",null);
        longitude=preferences.getString("longitude",null);
        getReport(lattitude,longitude);
        return root;
    }

    private void getReport(String lattitude,String longitude)
    {
        progressDialog= new ProgressDialog(getContext());
        progressDialog.setMessage("Please Wait..");
        progressDialog.setTitle("Loading.");
        progressDialog.setCancelable(false);
        progressDialog.show();
        RequestQueue rq= Volley.newRequestQueue(getContext());
        String url ="https://api.openweathermap.org/data/2.5/weather?lat="+lattitude+"&lon="+longitude+"&appid=638bd8e03959a48787aff704f2db772f";

        Log.e("finalURLLogin--->", url );
        StringRequest sr=new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response)
            {
                progressDialog.dismiss();
                try {
                    JSONObject jo = new JSONObject(response);
                    JSONObject data=new JSONObject(String.valueOf(jo.getJSONObject("main")));
                    double maxTemp=Double.valueOf(data.getString("temp_max"));
                    double minTemp=Double.valueOf(data.getString("temp_min"));
                    maxTemp=maxTemp-273.15;
                    minTemp=minTemp-273.15;


                }
                catch (JSONException e)
                {

                }

                ;
                Log.e("response:-->", response );
            }
        }, new Response.ErrorListener()
        {
            @Override
            public void onErrorResponse(VolleyError error)
            {
                progressDialog.dismiss();
                Toast.makeText(getContext(), "Some Technical Error!! Try Again", Toast.LENGTH_SHORT).show();
                // Toast.makeText(third.this, "DATA NOT REGISTER", Toast.LENGTH_SHORT).show();
                Log.e("error", error.getMessage() );
            }
        });

        rq.add(sr);

    }
}